/*
* Nebil Gokdemir
*
*
* */
public class MainClassForShopCart {


    public static void main(String[]args) {

        ShoppingCart nebilCart = new ShoppingCart();
        ShoppingCart lisaCart = new ShoppingCart();


        Customer nebil = new Customer(21321,"nebil","gokdemir", nebilCart);
        Customer lisa = new Customer(34,"lisa","jackson", lisaCart);

        CD c1 = new CD("CDplayer","not good",20.0,1233,30);
        Book b1 = new Book("bestbook","good",10.0,10,21321);
        Movie m1 = new Movie("ah marry ","okey",12.0,130,212);


nebil.getShoppingCartObject().addItem(c1);
nebil.getShoppingCartObject().addItem(b1);
nebil.getShoppingCartObject().addItem(m1);


nebil.getShoppingCartObject().removeItemInCart(m1);

nebil.getShoppingCartObject().printItem();










    }
}
