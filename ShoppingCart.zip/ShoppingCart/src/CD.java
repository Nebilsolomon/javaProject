
// I created this class for CD and extend Item Class
public class CD extends  Item {
  private int trackCount;

    public CD(String title, String description, Double price, int itemID , int trackCount) {
        super(title, description, price, itemID);
        this.trackCount = trackCount;
    }

// this method return trackcount of CD
    public int getTrackCount() {

        return trackCount;
    }
    // this method set trackCount of CD class

    public void setTrackCount(int trackCount) {

        this.trackCount = trackCount;
    }


    // this method is override of toString , and I return all property of Cd and Super class property
    @Override
    public String toString() {
        return "Item{" +
                "title='" + super.getTitle() + '\'' +
                ", description='" + super.getDescription() + '\'' +
                ", price=" + super.getPrice() +
                "rackCount" + getTrackCount()+

                '}';
    }


}
