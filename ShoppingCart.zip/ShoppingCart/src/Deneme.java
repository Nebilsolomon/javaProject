public class Deneme {


public static void main(String[] args) {

   ShoppingCart sCard = new ShoppingCart();

   Customer nebil = new Customer(21321,"nebil","gokdemir", sCard);
   Customer mehmet = new Customer(232,"mehmet","karatas",sCard);


   Book b1 = new Book("bestbook","good",10.0,10,21321);
   Movie m1 = new Movie("ah marry ","oket",1.0,130,21321312);


//nebil.getShoppingCartObject().addItem(m1);
//nebil.getShoppingCartObject().addItem(b1);
//nebil.getShoppingCartObject().printItem();

nebil.getShoppingCartObject().addItem(m1);
nebil.getShoppingCartObject().printItem();
    System.out.println("++===============");
mehmet.getShoppingCartObject().printItem();

}

}
