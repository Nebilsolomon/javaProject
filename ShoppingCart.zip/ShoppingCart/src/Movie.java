
// i made this class for Movie and I extends Items Class
public class Movie extends  Item{

  private int length;

    public Movie(String title, String description, Double price, int itemID , int length) {
        super(title, description, price, itemID);
        this.length = length;

    }

// this method is return length of Movie
    public int getLength() {

        return length;
    }

    // this method set Length of movie
    public void setLength(int length) {

        this.length = length;
    }

    // this method is override of toString , and I return all properties of Movie and super class as String
    @Override
    public String toString() {
        return "Item{" +
                "title='" + super.getTitle() + '\'' +
                ", description='" + super.getDescription() + '\'' +
                ", price=" + super.getPrice() + "length" + getLength() +
                '}';
    }
}
