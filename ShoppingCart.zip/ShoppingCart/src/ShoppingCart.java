import java.util.ArrayList;

public class ShoppingCart {
    private double totalValue = 0.0;
    // I made ArrayList and I made type of Item so we can add and delete object of type item
ArrayList<Item> shopCart = new ArrayList<>();

// this meethod return total value of item in cart
    public double getTotalValue() {
        return totalValue;
    }

    // this method is for adding object to arrayList
public void addItem(Item x ) {

// I put limited item to add to cart so customer cant add more than 10 item to their cart


    if(this.numberOfItemInCart() < 10) {

        shopCart.add(x);
        // as soon as customer add new item. Also totalValue of cart change by adding new item
        totalValue = totalValue + x.getPrice();

    }
    else {
        System.out.println("you can only have 10 item in cart");

    }
}


// this method is just print all item in cart


public void printItem() {
   double totalMoney = 0;
    for(Item x : shopCart) {

        System.out.println(x.getTitle());
        totalMoney = totalMoney + x.getPrice();

    }
    System.out.println("Total money is " + totalMoney);

}



// this method is for count number of item in arrayList

public int numberOfItemInCart() {
    int numberOfItem = 0;

    for(Item x : shopCart) {
        numberOfItem = numberOfItem + 1;

    }

    return  numberOfItem;

   }

// this method is for delete item in arrayList,



    public void removeItemInCart( Item newitem) {

      shopCart.remove(newitem);


      if(totalValue > newitem.getPrice()) {

      totalValue = totalValue - newitem.getPrice();

  }
        }








            }




