public class Customer {


private int id;
private String firtName;
private String lastName;
 private ShoppingCart shoppingCartObject;

    public Customer(int id, String firtName, String lastName, ShoppingCart x) {
        this.id = id;
        this.firtName = firtName;
        this.lastName = lastName;
        this.shoppingCartObject = x;


    }

    public int getId() {

        return id;
    }

    public void setId(int id) {

        this.id = id;
    }

    public String getFirtName() {

        return firtName;
    }

    public void setFirtName(String firtName) {

        this.firtName = firtName;
    }

    public String getLastName() {

        return lastName;
    }

    public void setLastName(String lastName) {

        this.lastName = lastName;
    }

    public ShoppingCart getShoppingCartObject() {

        return shoppingCartObject;
    }

    public void setShoppingCartObject(ShoppingCart shoppingCartObject) {

        this.shoppingCartObject = shoppingCartObject;
    }


    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", firtName='" + firtName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }
}
