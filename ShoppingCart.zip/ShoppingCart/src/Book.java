// I made this class for Book and I extends Item class
public class Book extends Item{
int pageCount;

    public Book(String title, String description, Double price, int itemID , int pageCount) {
        super(title, description, price, itemID);
        this.pageCount = pageCount;
    }

// this method return page number of class
    public int getPageCount() {


        return pageCount;
    }
// this method set page number of book
    public void setPageCount(int pageCount) {


        this.pageCount = pageCount;
    }

    //  this method is override of toString, and I returned all properties of Book and super class properties
    @Override
    public String toString() {
        return "Item{" +
                "title='" + super.getTitle() + '\'' +
                ", description='" + super.getTitle() + '\'' +
                ", price=" + super.getPrice() + "pageCount" + getPageCount() +
                '}';
    }

}
