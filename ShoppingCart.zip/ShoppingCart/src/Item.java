// I created this class to be super class of CD, Book and  Movie
public class Item {

private String title;
private String description;
private Double price;
private int itemID;



    public Item(String title , String description, Double price, int itemID ) {
    this.title = title;
    this.description = description;
    this.price = price;
    this.itemID = itemID;
}
// this method return Id of item
    public int getItemID() {
        return itemID;
    }
// this method set item id
    public void setItemID(int itemID) {
        this.itemID = itemID;
    }
// this method get title of item
    public String getTitle() {

        return title;
    }

    // this method set title of item
    public void setTitle(String title) {

        this.title = title;
    }
    // this method get description of item

    public String getDescription() {
        return description;
    }

    // this method set description of item
    public void setDescription(String description) {

        this.description = description;
    }

    // this method get price of item

    public Double getPrice() {

        return price;
    }

    // this method set price of item
    public void setPrice(Double price)
    {
        this.price = price;
    }

// this method is override of toString get return all property of item

    @Override
    public String toString() {
        return "Item{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                '}';
    }
}
