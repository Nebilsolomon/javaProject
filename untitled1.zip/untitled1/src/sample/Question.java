package sample;

public class Question {
    private String question;
    private Boolean correct_answer;
    private  String category;
    private String difficulty;

    public Question(String question, Boolean correct_answer , String category, String difficulty ) {
        this.correct_answer = correct_answer;
        this.question = question;
        this.difficulty =difficulty;
        this.category = category;
    }

    public String getQuestion()
    {
        return this.question;
    }

    public String getCategory() {
        return category;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public Boolean getCorrect_answer()
    {
        return this.correct_answer;
    }

    public void setQuestion(String question)
    {
        this.question = question;
    }

    public void setCorrect_answer(Boolean correct_answer) {

        this.correct_answer = correct_answer;
    }

    public String toString()

    {
        return "Question is " + this.getQuestion() + " answer is " + this.getCorrect_answer() + " difficulty is "+ getDifficulty() + " category " + getCategory();
    }
}
