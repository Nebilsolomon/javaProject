package sample;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Quize {
    ArrayList<Question> questionsBanks = new ArrayList();
    int count = 0;

    public Quize() {

        this.fetchData();
    }

    public ArrayList<Question> getQuestionsBanks() {

        return this.questionsBanks;
    }

    public void setQuestionsBanks(ArrayList<Question> questionsBanks) {
        this.questionsBanks = questionsBanks;
    }

    public void fetchData() {
        try {
            URL url = new URL("https://opentdb.com/api.php?amount=50&type=boolean");
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuffer response = new StringBuffer();

            String inputLine;
            while((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            in.close();
            JSONObject myResponce = new JSONObject(response.toString());

            for(JSONArray jsonArray = myResponce.getJSONArray("results"); this.count < 50; ++this.count) {
                JSONObject jsonObject2 = jsonArray.getJSONObject(this.count);
                String fetchQuestion = jsonObject2.getString("question");
                fetchQuestion = fetchQuestion.replace("&quot;", "''");
                fetchQuestion = fetchQuestion.replace("&#039;", "''");



                String fetchAnser = jsonObject2.getString("correct_answer");
                String fetchcategory = jsonObject2.getString("category");
                String fetchdifficulty = jsonObject2.getString("difficulty");
                Boolean convert = Boolean.valueOf(fetchAnser);

                Question question = new Question(fetchQuestion, convert, fetchcategory, fetchdifficulty);
                this.questionsBanks.add(question);
            }
        } catch (Exception var13) {
            System.out.println(var13.getMessage());
        }

    }
}
