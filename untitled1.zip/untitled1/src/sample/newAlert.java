package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class newAlert extends Application {

    Stage stage;
    Button play , exit;


    @Override
    public void start(Stage primaryStage) throws Exception {


    }



   public   void Alert(String message) {

        HBox hBox  = new HBox();
        hBox.alignmentProperty();
        Label label = new Label();
        label.setText(message);
        hBox.getChildren().add(label);
        Scene scene = new Scene(hBox,200,80);
        stage = new Stage();
        stage.setScene(scene);
        stage.showAndWait();


    }
public void closeWindow() {

        stage.close();
}


}
