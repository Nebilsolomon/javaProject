package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

public class Controller implements Initializable {



    Quize quize = new Quize();
    private  Random input = new Random();
    int point = 0;
    int count = input.nextInt(50);


    String question;
    Boolean answer;
    String cat;
    String difficulty;

    @FXML
    private AnchorPane backGround;

    @FXML
    private Label level;

    @FXML
    private Label score;

    @FXML
    private Label category;

    @FXML
    private Text lblQuestion;

    @FXML
    private Button btnTrue;

    @FXML
    private AnchorPane loserpane;

    @FXML
    private Button btnFalse;


    @FXML
    private Label scoreLabel;

    @FXML
    private Button btnPlayAgain;



    @FXML
    void onAnswerQuestion(ActionEvent event) {
        System.out.println("gokdmerr nebil " + count);
         question = quize.questionsBanks.get(count).getQuestion();
         answer = quize.questionsBanks.get(count).getCorrect_answer();
         cat = quize.questionsBanks.get(count).getCategory();
         difficulty = quize.questionsBanks.get(count).getDifficulty();

        System.out.println("==================before nextQuestion " + count);

        if (event.getSource() == btnTrue) {



            if (answer == true) {
                getPoint();


            } else {

                loserpane.setVisible(true);
                String newScorew = String.valueOf(point);
                scoreLabel.setText("Total score = " + newScorew);
                point= 0;
                score.setText("0");

            }


        } else if (event.getSource() == btnFalse) {
            //nextQuestion();
            if (answer == false) {
                getPoint();


            } else {
                loserpane.setVisible(true);
                String newScorew = String.valueOf(point);
                scoreLabel.setText("Total score = " + newScorew);
                point= 0;
                score.setText("0");

            }


        }
        nextQuestion();
        System.out.println("+++++++++after nextQuestion " + count);

    }

public void nextQuestion() {
    count = input.nextInt(50);
    System.out.println("nextQuestion count" + count);
    lblQuestion.setText(question);
    category.setText(cat);
    level.setText(difficulty);


}


    @Override
    public void initialize(URL location, ResourceBundle resources) {



        String question = quize.questionsBanks.get(count).getQuestion();
        Boolean answer = quize.questionsBanks.get(count).getCorrect_answer();
        String cate = quize.questionsBanks.get(count).getCategory();
        String levell = quize.questionsBanks.get(count).getDifficulty();

        lblQuestion.setText( question );
        category.setText(cate);
        level.setText(levell);
        backGround.setStyle( "-fx-background-color: rgba(50,205,50);" );


        System.out.println("nebil gokdmeirrrrrr " + count);

        loserpane.setVisible(false);





    }


    public void getPoint() {


        if(difficulty.equals("easy")) {
            point += 1;
            System.out.println("you got 1 point" +point);
        }
        else if(difficulty.equals("medium")){
            point+=3;
            System.out.println("you got 2 point" + point);

        } else if (difficulty.equals("hard")) {

            point+=5;

            System.out.println("you got 5 point" + point);
        }
        else {
            System.out.println("something go wrong");
        }

        String newScorew = String.valueOf(point);
        score.setText(newScorew);

    }

    @FXML
    public void onPlayAgain() {
        loserpane.setVisible(false);
        nextQuestion();

    }

}
