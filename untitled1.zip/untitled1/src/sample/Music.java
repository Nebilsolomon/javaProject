package sample;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Music {

    private MediaPlayer mediaPlayerForWinner;
    private Media mediaForWinner;
    private MediaPlayer mediaPlayerForLoser;
    private Media mediaForLoser;

    public Music() {
        init();
    }

    public void init() {
        mediaForWinner = new Media(getClass().getResource( "sample/coin_drop_sound.mp3" ).toExternalForm());
        mediaPlayerForWinner = new MediaPlayer( mediaForWinner );
//        mediaForLoser = new Media("sample/coin_drop_sound.mp3");
        mediaPlayerForLoser = new MediaPlayer(mediaForLoser);


    }

   public void playForwinner() {
      mediaPlayerForWinner.play();
   }

   public void playForloser() {
        mediaPlayerForLoser.play();
   }
}
