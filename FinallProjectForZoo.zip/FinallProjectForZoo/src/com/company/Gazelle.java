package com.company;
/*
Nebil Gokdemir
project: Zoo
class: CS56
 */

public class Gazelle extends Animal {
    public Gazelle(String name) {
        super(name);
    }

    // i made this extra method so that i can pass currentZoo so that i can set and get current Budget of it
    public Gazelle(String name, Zoo currentZoo) {
        super(name, currentZoo);
    }

/*
this method come from super class Animal and i set lion as enemy and i didn't give any name to lion becuase
when i add animals to Enclosure. I just made Crocodile and Zebra enemy because of UML
*/
    @Override
    public Animal getEnemy() {
        return new Lion("");
    }

        /*this method override from Animal class which is come from Feedable interface so
    because Gazelle eat Grass and Grass are 060$ and 900 dolar i set getCurrentZoo budget with -(600 + 900);

*/


    @Override
    public void feed()
    {
        this.getCurrentZoo().setBudget(this.getCurrentZoo().getBudget() - (600+900));
    }

     /*
    this method also came from animals feedable class
     */

    @Override
    public void getFeedingInstructions()
    {
        System.out.println(" Grass 600$" + " Grass 900$");
    }

    /*
override equals method from Object class
 */


    @Override
    public boolean equals(Object obj) {
        if(obj == this) {

            return true;
        }else {
            return  false;
        }
    }

    /*
    this method is come from Object class and get method of animals becuase animals also override that method
     */
    @Override
    public String toString()
    {
        return super.toString();
    }
}
