package com.company;

/*
Nebil Gokdemir
project: Zoo
class: CS56
 */
public class Enclosure {

    private String biome;
    private Animal[] animals;


public Enclosure(String biome) {
    this.biome = biome;
    animals = new Animal[10];

}

// this method getBiome of Enclosure

    public String getBiome()
    {
        return biome;
    }

    // this method setBiome
    public void setBiome(String biome)

    {
        this.biome = biome;
    }

// this method return animal array
    public Animal[] getAnimals()

    {
        return animals;
    }
    // this method get animals array

    public void setAnimals(Animal[] animals)
    {
        this.animals = animals;
    }


// this method add new animals to animals array
    public void addAnimal(Animal newAnimal) {
     int count = 0 ;
     /*
      this if condition check if newAnimal is instance of Crocodile or no and also if getBiome() is Savanna
      print Crocodile cant live in Savannah  if it is not match i will go else condition
      */

        if (newAnimal instanceof Crocodile && this.getBiome() == "Savanna") {
            System.out.println("Crocodile cant live in Savannah");

        }
        else {

            try {
                /*
                in this loop check all animal enemy in animals array and compare to newAnimal enemy if it is
                zebra and Crocodiles condition match   and it will print Crocodiles and Zebras are enemies else
                it will go else condition and add this animals to animals array
                Note: all animals enemy i set when i created their class.


                 */
                for (int i = 0; i < animals.length; i++) {
                    if (newAnimal.getEnemy().getName().equals("Gena") && animals[i].getEnemy().getName().equals("Zebby")) {
                        System.out.println("Crocodiles and Zebras are enemies");
                        i = animals.length;

                    } else {
                        if(count< 10) {

                            animals[count] = newAnimal;
                            count++;

                            i = animals.length;
                        }
                    }
                }

            } catch (Exception e) {


            }
        }

    }

// this method override from Object class

    @Override
    public boolean equals(Object obj) {
        if(obj == this) {

            return true;
        }else {
            return  false;
        }
    }
    // this method override from Object class

    @Override
    public String toString() {
        return "Enclosure{" +
                "biome='" + biome + '\'' +
                '}';
    }





}
