package com.company;
/*
Nebil Gokdemir
project: Zoo
class: CS56
 */

public class Crocodile extends Animal {

   public Crocodile(String name) {
       super(name);
   }

// i made this extra method so that i can pass currentZoo so that i can set and get current Budget of it
    public Crocodile(String name, Zoo currentZoo) {
        super(name, currentZoo);
   }
/*

 this method override from animal class and i set enemy of Crocodile as Zebra
 when we add animals to Enclosure it will match to Zebra and not add in Enclosure

 */


    @Override
    public Animal getEnemy()
    {
        return new Zebra("Zebby");
    }


    /*this method override from Animal class which is come from Feedable interface so
    because Crocodile eat meat and meat is 5000$ dolar i set getCurrentZoo budget with -5000$

     */
    @Override
    public void feed() {
        this.getCurrentZoo().setBudget(this.getCurrentZoo().getBudget()-5000);
    }

    /*
    this method also came from animals feedable class
     */
    @Override
    public void getFeedingInstructions() {
        System.out.println("Crocodile eat meat : 5000$");
    }

/*
override equals method from Object class
 */
    @Override
    public boolean equals(Object obj) {
        if(obj == this) {

            return true;
        }else {
            return  false;
        }
    }

    /*
    override toString method from super class animal which is come from Object class
     */

    @Override
    public String toString() {
        return super.toString();
    }
}
