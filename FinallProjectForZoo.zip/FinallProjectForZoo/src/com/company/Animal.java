package com.company;

import java.util.Objects;
/*
Nebil Gokdemir
project: Zoo
class: CS56
 */

public class Animal  implements  Feedable{


    private String name;
    private String genus;
    private String species;
    private Zoo currentZoo;
    protected Animal enemy;
    protected String prefferedBiome;




    public Animal(String name)
    {
        this.name = name;
    }


    public Animal(String name, Zoo currentZoo) {
        this.name = name;
        this.currentZoo = currentZoo;

    }
 /*
 this method came from Feedable interface
  */
    @Override
    public void getFeedingInstructions() {

    }

    /*
this method came from Feedable interface
 */
    @Override
    public void feed() {

    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getGenus()
    {
        return genus;
    }

    public void setGenus(String genus)
    {
        this.genus = genus;
    }

    public String getSpecies()
    {
        return species;
    }

    public void setSpecies(String species)
    {
        this.species = species;
    }

    public Zoo getCurrentZoo()
    {
        return currentZoo;
    }

    public void setCurrentZoo(Zoo currentZoo) {
        this.currentZoo = currentZoo;
    }

    public Animal getEnemy()
    {
        return enemy;
    }

    public void setEnemy(Animal enemy)
    {
        this.enemy = enemy;
    }

    public String getPrefferedBiome()
    {
        return prefferedBiome;
    }

    public void setPrefferedBiome(String prefferedBiome) {
        this.prefferedBiome = prefferedBiome;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                ", currentZoo=" + currentZoo.getName() +
                '}';
    }


    @Override
    public boolean equals(Object obj) {
        if(obj == this) {

            return true;
        }else {
            return  false;
        }
    }
}
