package com.company;

import java.util.Arrays;

/*
Nebil Gokdemir
project: Zoo
class: CS56
 */
public class Zoo {

    private String name;
    private String address;
    private Enclosure[] enclosures;
    private int area;
    private double budget;
    private int count = 0 ;

    public Zoo(String name, String address, Enclosure[] enclosures, int area, double budget) {
        this.name = name;
        this.address = address;
        this.enclosures = enclosures;
        this.area = area;
        this.budget = budget;

        enclosures = new Enclosure[10];
    }
    public Zoo(String name, String address,  int area, double budget) {
        this.name = name;
        this.address = address;
        this.area = area;
        this.budget = budget;
        enclosures = new Enclosure[10];
    }




    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public Enclosure[] getEnclosures() {
        return enclosures;
    }

    public void setEnclosures(Enclosure[] enclosures) {
        this.enclosures = enclosures;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

  /*
  this method get new Enclosure to add Enclosure array
   */
    public void addEnclosure(Enclosure newEnclosure) {
       if(count< 10){
        enclosures[count] = newEnclosure;
        count++;
       }

    }

/*
this method go inside zoo and inside zoo check all Enclosure and inside Enclosure check all animal class and call
feed method

 */

    public void feed() {

        for(int i = 0; i < enclosures.length; i++) {

         if(enclosures[i] != null) {
           //  enclosures[i].getAnimals();
             for (int k = 0; k < enclosures[i].getAnimals().length; k++) {
            if(enclosures[i].getAnimals()[k] != null) {
                 enclosures[i].getAnimals()[k].feed();
             }}
         }
         }
/*
this if condtion check if getBudget is positive of negative
 */
        if(this.getBudget() < 0 ) {

            System.out.println("Zoo doesn't have enough money to feed all the animals, so we add more money to the Zoo.\n");
        }
        else {
            System.out.println("Zoo have enough money to feed all the animals");
        }



    }

/*

this method go inside enclosure and from enclosure check each animal and call getFeedingInstructions method
 */
public void getFeedingInstructions() {


    for(int i = 0; i < enclosures.length; i++) {

        if(enclosures[i] != null) {
            //  enclosures[i].getAnimals();
            for (int k = 0; k < enclosures[i].getAnimals().length; k++) {
                if(enclosures[i].getAnimals()[k] != null) {
                    enclosures[i].getAnimals()[k].getFeedingInstructions();
                }}
        }
    }






}


// this method come from Object class

    @Override
    public String toString() {
        return "Zoo{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", area=" + area +
                ", budget=" + budget +
                '}';
    }
}
