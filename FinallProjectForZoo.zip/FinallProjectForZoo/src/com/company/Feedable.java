package com.company;

/*
Nebil Gokdemir
project: Zoo
class: CS56
 */
public interface Feedable {


    void getFeedingInstructions();
    void feed();

}
