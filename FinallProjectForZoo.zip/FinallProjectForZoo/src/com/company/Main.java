package com.company;
/*
Nebil Gokdemir
project: Zoo
class: CS56
 */
public class Main {

    public static void main(String[] args) {

        Zoo laZoo = new Zoo("Los Angeles Zoo", "5333 Zoo Dr, Los Angeles, CA 90027", 133, 0);
        Enclosure firstEnclosure = new Enclosure("Savanna");
        Enclosure secondEnclosure = new Enclosure("River");

        Zebra zeb = new Zebra("Zebby",laZoo);
        Gazelle gaz = new Gazelle("Gaz",laZoo);
        Crocodile croc = new Crocodile("Gena",laZoo);
        Lion leo = new Lion("Leo",laZoo);

        firstEnclosure.addAnimal(croc);
        firstEnclosure.addAnimal(leo);
        secondEnclosure.addAnimal(croc);
        secondEnclosure.addAnimal(zeb);

        Enclosure thirdEnclosure = new Enclosure("Savanna");

        thirdEnclosure.addAnimal(zeb);
        thirdEnclosure.addAnimal(gaz);


        laZoo.addEnclosure(firstEnclosure);
        laZoo.addEnclosure(secondEnclosure);
        laZoo.addEnclosure(thirdEnclosure);

        System.out.println(laZoo);
        laZoo.feed();
        laZoo.setBudget(999999999);
        laZoo.feed();

        laZoo.getFeedingInstructions();

















    }
}
