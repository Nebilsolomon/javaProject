package com.company;
/*
Nebil Gokdemir
project: Zoo
class: CS56
 */
public class Lion extends Animal {


   public Lion( String name ){
       super(name);
   }
/*

 i made this extra method so that i can pass currentZoo so that i can set and get current Budget of it

 */

    public Lion(String name, Zoo currentZoo)

    {
        super(name, currentZoo);
    }

    /*
this method come from super class Animal and i set Gazelle as enemy and i didn't give any name to Gazelle becuase
when i add animals to Enclosure. I just made Crocodile and Zebra enemy because of UML
 */

    @Override
    public Animal getEnemy()
    {
        return new Gazelle("");
    }


        /*this method override from Animal class which is come from Feedable interface so
    because Lion eat meat and meat is  5000 dolar i set getCurrentZoo budget with -(5000);

*/

    @Override
    public void feed()
    {
       this.getCurrentZoo().setBudget(this.getCurrentZoo().getBudget() - 5000);
    }

    /*
    i this method also came from Animals method which is implement from interface Feedable
     */

    @Override
    public void getFeedingInstructions() {

        System.out.println("Lion eat meat 5000$");
    }

    /*
    this method came from Also from Animal method which is override from  Object class
     */
    @Override
    public String toString()
    {
        return super.toString();
    }

    /*
       this method came from Also from Animal method which is override from  Object class
        */
    @Override
    public boolean equals(Object obj) {
        if(obj == this) {

            return true;
        }else {
            return  false;
        }
    }
}
