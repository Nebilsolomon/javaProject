package com.company;

/*
Nebil Gokdemir
project: Zoo
class: CS56
 */
public class Zebra extends Animal {


    public Zebra(String name)
    {
        super(name);
    }

    /*

 i made this extra method so that i can pass currentZoo so that i can set and get current Budget of it

 */

    public Zebra(String name, Zoo currentZoo) {
        super(name, currentZoo);
    }

/*
  this method override from animal class and i set enemy of  Zebra as Crocodile so that when we add animals

  to Enclosure it will match to Crocodile and not add in Enclosure
 */



    @Override
    public Animal getEnemy() {
        return new Crocodile("Gena");
    }

    /*

    this method override from Animal class which is come from Feedable interface so
    because Zebra eat Grass and Grass are   600 and 900 dolar i set getCurrentZoo budget with -(600 + 900);

*/


    @Override
    public void feed()
    {
       this.getCurrentZoo().setBudget(this.getCurrentZoo().getBudget() -(600+900));
    }


    /*

    this method is came from Animal class which is also implement from Feedable interface
     */
    @Override
    public void getFeedingInstructions() {
        System.out.println("Zebra eat a) Grass 600$\n" +
                "b) Grass 900$\n");
    }


      /*
    this method came from Also from Animal method which is override from  Object class
     */

    @Override
    public String toString() {
        return super.toString();
    }



    /*
     this method came from Also from Animal method which is override from  Object class
      */
    @Override
    public boolean equals(Object obj) {
        if(obj == this) {

            return true;
        }else {
            return  false;
        }
    }
}
