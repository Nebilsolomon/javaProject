package com.company;

/*
 * Nebil Gokdemir
 * Assigment #1
 *
 * This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
 * who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
 * for banking customer and student class which is subclass of Person Class.
 *
 * */

public class StudentAccount extends BasicAccount {


    public StudentAccount(int acctId, Person owner, String bank) {
        super(acctId, owner, bank);
    }
 // this method is override from BasicAccount and return 0 assessMaintenanceFee for student
    @Override
    public double assessMaintenanceFee() {
        return 0.0;
    }
}
