package com.company;

/*
 * Nebil Gokdemir
 * Assigment #1
 *
 * This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
 * who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
 * for banking customer and student class which is subclass of Person Class.
 *
 * */

public class BasicAccount {

    protected int acctId;
    protected Person owner;
    protected String bank;
    protected double balance;
    protected double intRate;
    protected double maintFee;

    public BasicAccount(int acctId, Person owner, String bank) {
            this.acctId = acctId;
            this.owner = owner;
            this.bank = bank;


    }

    // this method add deposit to balance
    public double deposit(double amount) {
        if(amount > 0) {
            balance = balance + amount;
        }
        else {
            System.out.println("amount has to be positive");
        }

        return balance;

    }

    // this method withdraw money from  balance

    public double withdraw(double amount) {

  if(amount > 0 && balance > amount) {

      balance = balance - amount;
      return  amount;

   } else {

      return 0.0;
  }


    }

    // this method setBalance
    public  void setBalance(double balance) {
        this.balance = balance;
    }

    // this method getBalance
    public double getBalance() {
        return this.balance;
    }

  // this method getId of user
    public int getAcctId() {

        return this.acctId;
    }

    // this method return person of bank
    public Person getOwner() {

        return this.owner;
    }


    // this method setInterestRate
    public void setInterestRate(double intRate) {

        this.intRate = intRate;

    }

    // this method  setMaintFee

    public void setMaintFee(double maintFee) {
        this.maintFee = maintFee;

    }


    // this method  addInterest
    public void addInterest() {


        balance = (balance * this.intRate) + balance;
    }

// this method return  assessMaintenanceFee
    public double assessMaintenanceFee() {


        return maintFee;
    }

// this method give info bank user
    public String toString() {
        return  "account owner is " + owner.getName() + " ID " + this.acctId + "Balance is " + this.getBalance();

    }


  // this method is checking is same user or not

    public boolean equals(Object other) {
        if ((((BasicAccount) (other)).acctId == this.acctId)
                && (((BasicAccount) (other)).bank == this.bank)) {
            return true;
        }
        return false;
    }





    }








