package com.company;
import java.util.Random;
import java.util.Scanner;




/*
 * Nebil Gokdemir
 * Assigment #1
 *
 * This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
 * who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
 * for banking customer and student class which is subclass of Person Class.
 *
 * */
public class Main {




    public static void main(String[] args) {
        // write your code here
        Bank b = new Bank("Bank of Rupt");
        b.setIntRate(0.1);
        b.setMaintFee(50);

        Person bob = new Person(11315, "Bob");
        int bobAcctId = b.openAccount(bob, 1000);

        Person alice = new Student(12512, "Alice", 1233, "SMC");
        int aliceAcctId = b.openAccount(alice, 500);

        Person rich = new Person(51542, "Rich P. Person");
        int richAcctId = b.openAccount(rich, 1000000);

        Person richStudent = new Student(23814, "Rich S. Student", 1192, "SMC");
        int richStudentAcctId = b.openAccount(richStudent, 100100);

        // another account for Rich S. Student
         b.openAccount(richStudent, 30000);

        // another account for Alice
        b.openAccount(alice, 100);


        // another account for Bob
         b.openAccount(bob, 5000);

        System.out.println("All the accounts: ");
        b.printAllAccounts();
        System.out.println();

        System.out.println("All the accounts of Alice: ");
        b.printAccountsForOwner(alice);
        System.out.println();

        System.out.println("Paying interest : ");
        b.payInterest();
        b.printAllAccounts();
        System.out.println();


        System.out.println("Assessing maintenance fees: ");
        b.assessMaintenanceFee();b.printAllAccounts();
        System.out.println();

        System.out.println("Rich P. Person buys a Ferrari, Alice wins the lottery, Rich. S. Student pays tuition ...");
        b.withdraw(richAcctId, 331000);
        b.printAccountsForOwner(rich);
        b.deposit(aliceAcctId, 100000);

        b.printAccountsForOwner(alice);
        b.withdraw(richStudentAcctId, 45000);
        b.printAccountsForOwner(richStudent);
        System.out.println();










    }

}
