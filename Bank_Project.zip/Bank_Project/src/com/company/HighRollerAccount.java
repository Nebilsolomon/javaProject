package com.company;

/*
* Nebil Gokdemir
* Assigment #1
*
* This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
* who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
* for banking customer and student class which is subclass of Person Class.
*
* */

public class HighRollerAccount extends BasicAccount {


    public HighRollerAccount(int acctId, Person owner, String bank) {
        super(acctId, owner, bank);
    }
// this method Override from BasicAccount and it adds interest to balance of user
    @Override
    public void addInterest() {
      //  balance = (balance * intRate) + ((balance * intRate + balance) * intRate) + balance;
        super.balance = (super.balance * super.intRate) + ((super.balance * super.intRate + super.balance) * super.intRate) + super.balance;
    }

// this method also Override from BasicAccount and return assessMaintenanceFee of user
    @Override
    public double assessMaintenanceFee() {
        return super.assessMaintenanceFee();
    }

   // this method override from super Object class and return all info of user
    @Override
    public String toString() {
        return "HighRoller " + super.toString();
    }
}
