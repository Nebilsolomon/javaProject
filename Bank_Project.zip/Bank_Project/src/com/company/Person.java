package com.company;


/*
 * Nebil Gokdemir
 * Assigment #1
 *
 * This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
 * who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
 * for banking customer and student class which is subclass of Person Class.
 *
 * */
public class Person {

    protected int id;
    protected String name;
    protected String address;


    public Person(int id, String name)
    {
    this.id = id;
    this.name = name;

    }
//set address property of person
    public void setAddress(String address) {
        this.address = address;

    }

 // return id of person
    public int getId() {

        return this.id;


    }
 // return name of person
    public String getName() {
        return  this.name;


    }
  // return information of person
    public String toString() {

        return "Person name " + getName() + " and id is " + getId();
    }


// this method check if same user or not and return boolean value

    public boolean equals(Object other) {
        if ((((Person) (other)).id == this.id)
                && (((Person) (other)).name == this.name)) {
            return true;
        }
        return false;
    }
}




