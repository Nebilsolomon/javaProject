package com.company;

/*
 * Nebil Gokdemir
 * Assigment #1
 *
 * This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
 * who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
 * for banking customer and student class which is subclass of Person Class.
 *
 * */



import java.lang.reflect.Array;
import java.util.Arrays;

public class Bank {
    private BasicAccount[] accounts;
    private String name;
    private double maintFee;
    private double intRate;
    private int nextId;
    private final double HIGH_ROLLER_LIMIT = 100000;


    public Bank(String name) {
        this.name = name;
        accounts = new BasicAccount[2];
        nextId = 0;
    }


// this method set Rate
    public void setIntRate(double intRate) {

    this.intRate = intRate;

    }
    // this method set main fee

    public void setMaintFee(double maintFee) {
     this.maintFee = maintFee;

    }
 /*
  this method open new account for user and if there is enough length in array it extend couple length
  also there 3 different account if balance is higher than HIGH_ROLLER_LIMIT open once and if it is not
  open two different account base of condition of user is student or not


  */

    public int openAccount(Person owner, double balance) {
   if(accounts[accounts.length-1] != null) {

       accounts = Arrays.copyOf(accounts, accounts.length * 2);

   }



    if (balance >=HIGH_ROLLER_LIMIT){

        HighRollerAccount newAccount = new HighRollerAccount(nextId,owner,"Well Fargo");
        newAccount.setBalance(balance);
        newAccount.setInterestRate(this.intRate);
        newAccount.setMaintFee(this.maintFee);
        accounts[nextId] = newAccount;


    }
    else {

        if(owner instanceof Student){
           StudentAccount newAccount = new StudentAccount(nextId,owner,"Well Fargo");
            newAccount.setBalance(balance);
            newAccount.setInterestRate(this.intRate);
            newAccount.setMaintFee(this.maintFee);
            accounts[nextId] = newAccount;

        }else {

            BasicAccount newAccount = new BasicAccount(nextId,owner,"Well fargo");
            newAccount.setBalance(balance);
            newAccount.setInterestRate(this.intRate);
            newAccount.setMaintFee(this.maintFee);
            accounts[nextId] = newAccount;
        }




    }

        nextId++;
        return nextId -1 ;


    }



// this method return total of account in accounts array fees


    public double assessMaintenanceFee() {
    double totalFee = 0 ;
        for(int i = 0; i < accounts.length; i ++) {

        if(accounts[i] != null ) {
            totalFee = accounts[i].assessMaintenanceFee() + totalFee;
        }

    }
    return totalFee;
    }


// this method check all account and add interest to account also call changeAccountType method make sure all account become HIGH_ROLLER_LIMIT or not

    public void payInterest() {
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null) {
                accounts[i].addInterest();
                if (accounts[i].balance > HIGH_ROLLER_LIMIT) {
                    changeAccountType(accounts[i].acctId);
                }
            }
        }
    }

// this method check all account base of id and deposit account and invoke changeAccountType to check if acoount is HIGH_ROLLER_LIMIT or not
    public void deposit(int acctId, double amount) {

        for(int i = 0; i < accounts.length; i++) {

            if (accounts[i] != null) {
                if (accounts[i].acctId == acctId) {
                    accounts[i].deposit(amount);
                    if (accounts[i].balance > HIGH_ROLLER_LIMIT) {
                        changeAccountType(accounts[i].acctId);
                    }
                }
            }

        }



    }

// this method check all account on array by id and withdraw money
    public void withdraw(int acctId, double amount) {
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null) {
                if (accounts[i].acctId == acctId) {
                    accounts[i].withdraw(amount);
                    if (accounts[i].balance > HIGH_ROLLER_LIMIT) {
                        changeAccountType(accounts[i].acctId);
                    }
                }
            }
        }
    }



// this method printAllAccounts
    public void printAllAccounts() {
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null) {
                System.out.println(accounts[i].toString());
            }
        }
    }



// method check if same owner if it print all info of it

    public void printAccountsForOwner(Person owner) {
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null) {
                if (accounts[i].owner.equals(owner)) {
                    System.out.println(accounts[i].toString());
                }
            }
        }
    }






// this method base on id check all account in array and if account is HIGH_ROLLER_LIMIT , it make it
    private void changeAccountType(int acctId) {


        for(int i = 0 ; i < accounts.length; i++) {

    if (accounts[i] != null) {
        if (accounts[i].acctId == acctId) {

            if (accounts[i].getBalance() > HIGH_ROLLER_LIMIT) {

                accounts[i] = new HighRollerAccount(accounts[i].acctId, accounts[i].owner, accounts[i].bank);


            } else {
                if (accounts[i].owner instanceof Student) {

                    StudentAccount newAcc = new StudentAccount(acctId, (Student) accounts[i].owner, accounts[i].bank);
                    newAcc.balance = accounts[i].balance;
                    newAcc.intRate = accounts[i].intRate;
                    newAcc.maintFee = accounts[i].maintFee;
                    accounts[i] = newAcc;

                } else {

                    BasicAccount newAcc = new BasicAccount(acctId, accounts[i].owner, accounts[i].bank);
                    newAcc.balance = accounts[i].balance;
                    newAcc.intRate = accounts[i].intRate;
                    newAcc.maintFee = accounts[i].maintFee;
                    accounts[i] = newAcc;
                    }




            }
        }
    }
   }
    }

}


