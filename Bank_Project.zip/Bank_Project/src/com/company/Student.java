package com.company;


/*
 * Nebil Gokdemir
 * Assigment #1
 *
 * This project is for banking. There are 2 type of account basic and non student. Also there is highRoller Account
 * who is balance is higher than 100000. basic account is super class of student and basic Account. Also there is person class
 * for banking customer and student class which is subclass of Person Class.
 *
 * */
public class Student extends Person {

    protected int sId;
    protected String school;

    public Student(int id, String name, int sid ,String school) {
        super(id, name);

        this.sId = sid;
        this.school = school;

    }
  // this method return school of student
    public String getSchool() {

        return this.school;

    }
  // this method return student id
    public int getSId() {
        return  this.sId;
    }
   // toString method give info about student
    public String toString() {

        return "Student name is " + getName() + " school name is " + getSchool();
    }




}
