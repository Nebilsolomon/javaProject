package com.company;

import java.util.Objects;

public class Book extends Item {

    int pageCount;

    public Book(String title, String description, int price , int pageCount) {

        super(title, description, price);
        this.pageCount = pageCount;
    }


    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }


    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return super.toString() + " pageCount is " + getPageCount();
    }


}
