package com.company;

public class Customer {

    private int id;
    private String firstName;
    private String lastName;
    private ShoppingCar shoppingCar;


    public Customer() {
        shoppingCar = new ShoppingCar();

    }

    public Customer(int id, String firstName, String lastName, ShoppingCar shoppingCar) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.shoppingCar = shoppingCar;

    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public String getFirstName() {
        return firstName;
    }


    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public ShoppingCar getShoppingCar()
    {
        return shoppingCar;
    }

    public void setShoppingCar(ShoppingCar shoppingCar)
    {
        this.shoppingCar = shoppingCar;
    }

    @Override
    public String toString() {
        return  "Customer name is " + getFirstName() +  " lastname is " + getLastName() + " id is " + getId();
    }
}
