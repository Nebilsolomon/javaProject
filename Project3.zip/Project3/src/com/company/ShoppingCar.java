package com.company;

import java.util.ArrayList;

public class ShoppingCar {

    ArrayList<Item> shopCart;


    public ShoppingCar() {

        shopCart = new ArrayList<>();
    }


    public void addItem(Item item) {

        shopCart.add(item);

    }

    public void  printItems(){


        for(Item x : shopCart) {
            System.out.println(x.toString());
        }
    }


      public void removeItemInCart(Item item) {

         if(shopCart.contains(item)){

                shopCart.remove(item);
             System.out.println(" ="+ item.getTitle() + " is just got delete from ShoppingCart = ");
            }
         else {
             System.out.println(item.getTitle() + " is not in shopCart");
         }
          }



     public int checkOutTotal() {
        int totalCheck = 0;

        for(Item x : shopCart) {
            totalCheck = x.getPrice() + totalCheck;

        }
        return totalCheck;
      }



    public int numberOfItemInCart() {

        return  shopCart.size();

    }
}
