package com.company;

public class CD extends Item {

  int trackCount;
    public CD(String title, String description, int price, int trackCount) {

        super(title,description,price);

        this.trackCount = trackCount;

    }

    public void setTrackCount(int trackCount) {
        this.trackCount = trackCount;
    }

    public int getTrackCount() {
        return trackCount;
    }

    @Override
    public String toString() {
        return super.toString() + " trackCount is " + getTrackCount();
    }
}
