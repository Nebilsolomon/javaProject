package com.company;

public class Movie extends Item{
  int length;

    public Movie(String title, String description, int price , int length) {
        super(title,description,price);
       this.length = length;

    }


    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public String toString() {
        return super.toString() + " length is " + getLength();
    }
}
