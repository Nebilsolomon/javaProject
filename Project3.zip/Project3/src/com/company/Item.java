package com.company;

import java.util.Objects;

public class Item {
    private  String title;
    private String description;
    private  int price ;

    public Item(String title, String description, int price) {
        this.title = title;
        this.description = description;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) {
            return  false;
        }
        if (!(o instanceof Item)) return false;
        Item item = (Item) o;
        return price == item.price &&
                title.equals( item.title ) &&
                description.equals( item.description );
    }

    @Override
    public int hashCode() {
        return Objects.hash( title, description, price );
    }

    @Override
    public String toString() {

        return "title is " + getTitle() + " description " + getDescription() + " price " + getPrice();

    }
}
