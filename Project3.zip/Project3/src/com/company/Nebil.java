package com.company;

public class Nebil {
    String name;

//    public Nebil( String name) {
//        this.name = name;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "my name is " + getName();
    }
}
