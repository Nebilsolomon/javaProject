package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main extends Thread {

    public static void main(String[] args) {
        // write your code here
        Book book1 = new Book( "kiziltepe", "bestbookofyear", 10, 100 );
        Book book2 = new Book("newBook","helodfvd",100,20);
        CD cd1 = new CD("cd","okey",10,232);
        Movie movie1 = new Movie("mehlul","ahlaksiz",10,100);
        ShoppingCar shoppingCar1 = new ShoppingCar();

        Customer customer1 = new Customer(123,"nebil","gokdemir",shoppingCar1);

        shoppingCar1.addItem(book1);
        shoppingCar1.addItem(cd1);
        shoppingCar1.addItem(movie1);


//        System.out.println("===============");
//
//        customer1.getShoppingCar().addItem(book2);
//        customer1.getShoppingCar().printItems();
//        System.out.println(shoppingCar1.numberOfItemInCart());
//        System.out.println(customer1.getShoppingCar().numberOfItemInCart());

       new Main().start();


    }


    @Override
    public void run() {

        try {
        for ( int i =0 ; i < 100; i++) {
//            Scanner input = new Scanner(System.in);
//            String name ;
//
//            System.out.println("what your name");
//            name = input.next();
//            Nebil nebil = new Nebil(name);
//            System.out.println(nebil.toString());
//
//        }

           Customer customer =  new Customer(i,nameRetrieve(), lastRetrieve() + i,new ShoppingCar());

            Thread.sleep(1000);
            System.out.println(customer.toString());

        }


    }catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }

    int number = -1;
    public String nameRetrieve() {
        String[] names = {"Cris", "Jose", "Nebil", "Jon", "Asajan", "Sergio"};

        number++;

        if(number == 6)
            number = 0;

        return names[number];

    }



    public String lastRetrieve() {
        String[] names = {"Thiticharoen", "DLC", "Gokdemir", "RAFARALAHITOETRA", "RAZNIK", "SEWRA"};

        number++;

        if(number == 6)
            number = 0;

        return names[number];

    }
}
