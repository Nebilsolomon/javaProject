package com.company;

public class Bookshelf {
    int count = 0;
    private String name;
    Book[] bShelf = new Book[5];


    public Bookshelf(String name) {
        this.name = name;
    }


    public void addBookToBookShelf(Book x) {


        if (count < 5) {


            bShelf[count] = x;

            count = count + 1;

            System.out.println("you add new book");
          //  System.out.println("you add " + bShelf[count].getAuthor());


        } else {
            System.out.println("only you can have 5 book");
        }


    }


    public void isDuplicate(Book b) {

        for (int i = 0; i < bShelf.length; i++) {

            if (bShelf[i] == b && bShelf[i] != null) {
                System.out.println("you can't Duplicate");
            } else {
                bShelf[i] = b;


            }

        }


    }


    public void removesBook(Book x) {
        for (int i = 0; i < bShelf.length; i++) {

            if (x == bShelf[i] && bShelf[i] != null) {

                System.out.println("we remomve " + bShelf[i].getAuthor());
                bShelf[i] = null;


            }



        }


    }


    public boolean isFull() {
        int count = 0;
        boolean trueOrFalse = false;
        for (int x = 0; x < bShelf.length; x++) {

            if (bShelf[x] != null) {
                count++;

            }
   if(count == 5) {
       trueOrFalse =true;
   }
   else {
       trueOrFalse = trueOrFalse;
   }


        }

        return trueOrFalse;
    }



    public boolean isEmpty() {
        int count = 0 ;
        boolean trueOrFalse = false;
        for(int x = 0; x < bShelf.length; x++) {
           if(bShelf[x] == null) {
               count ++;
           }

           if(count == 5 ){

               trueOrFalse = true;
           }
           else {
               trueOrFalse =false;
           }


        }


        return trueOrFalse;
    }





    public String findAutherr(String x) {

        String autherInformation = "";

        for(int i = 0; i< bShelf.length; i++) {

        if(bShelf[i] != null && bShelf[i].getAuthor().equals(x)){

            autherInformation =  bShelf[i].toString();


        }

      }

       return   autherInformation;
    }


//    @Override
//    public String toString() {
//
//
//        return "Bookshelf{}";
//    }


    @Override
    public String toString() {
     String out = "" ;

        for (int x = 0 ; x < bShelf.length; x++) {

            if(bShelf[x] !=null) {

                out += bShelf[x].toString() + "\n" + "\n";


            }
        }
        return  out;








    }




}