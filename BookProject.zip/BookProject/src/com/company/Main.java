package com.company;

public class Main {

    public static void main(String[] args) {
        Bookshelf input = new Bookshelf("smc book store");

Book b1 = new Book("benim adim kirmizi","mehmetuzun","i dont know" , 20,1989);
Book b2 = new Book("nebil","cl;lx;c ","i dont know" , 70,1290);
Book b3 = new Book("evett","hilmi","i dont know" , 80,21);
Book b4 = new Book("gokdemirrr","cl;lx;c ","i dont know" , 1000,2313);
Book b5 = new Book("nerede","SMC  ","great book" , 320,123);




input.addBookToBookShelf(b1);
input.addBookToBookShelf(b2);
input.addBookToBookShelf(b3);
input.removesBook(b2);

        System.out.println("===============");
       System.out.println(input.findAutherr("hilmi"));
        System.out.println("===============");
        System.out.println(input.isEmpty());
        System.out.println(input.isFull());
        input.removesBook(b1);

        System.out.println(input.toString());



//
//       for (int x = 0 ; x < input.bShelf.length; x++) {
//
//           if(input.bShelf[x] !=null)
//
//
//           System.out.println(input.bShelf[x].toString() + "\n");
//
//       }







    }


}

