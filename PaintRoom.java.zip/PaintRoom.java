package com.company;
import java.util.Scanner;


// Nebil Gokdemir

public class PaintRoom {

    public static void main(String[] args) {

         paintRoom();


    }




    public static void paintRoom() {

        Scanner input = new Scanner(System.in);
        double totalSqFt , paintNeeded;
        final int coverage = 350;
        final int door = 20;
        final int window = 15;
        int length, width, height, numberOfroom, numberOfWindow;

        //  2 * width * height + 2 * length * height - DOOR*doors - WINDOW*windows;
       System.out.println("lenght of your room");
             length = input.nextInt();
        System.out.println("width of your room");
             width = input.nextInt();
        System.out.println("height of your room");
             height = input.nextInt();
        System.out.println("how many door do you have in your room");
             numberOfroom = input.nextInt();
        System.out.println("how many window do you have in your room");
            numberOfWindow = input.nextInt();


    totalSqFt = (2 * width * height) + (2 * length * height) - (door * numberOfroom) - (window * numberOfWindow);

        paintNeeded = totalSqFt / coverage ;
        System.out.println("length of room is " + length + "  width of room is " + width + "   height of room is " + height );
        System.out.println(paintNeeded +"  number of gallons of paint needed.");
    }
}
